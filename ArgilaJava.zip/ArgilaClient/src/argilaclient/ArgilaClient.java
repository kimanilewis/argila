/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package argilaclient;


import com.sun.jmx.snmp.Timestamp;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.MqttTopic;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

/**
 *
 * @author crazywizard
 */
public class ArgilaClient implements MqttCallback {

    /**
     * @param args the command line arguments
     */
    MqttClient client;
    String topic = "broadcast";
    String content = "";
    int qos = 2;
    String broker = "tcp://iot.eclipse.org:1883";
    String clientId = "123";
    MemoryPersistence persistence = new MemoryPersistence();

    public static void main(String[] args) {
       ArgilaClient argilaClient = new ArgilaClient();
       argilaClient.runClient();
    }

    public void runClient() {

        try {
            // Construct the connection options object that contains connection parameters  
            MqttConnectOptions connOpts = new MqttConnectOptions();
            connOpts.setCleanSession(true);

            // Construct an MQTT blocking mode client
            client = new MqttClient(broker, clientId, persistence);

            // Set this wrapper as the callback handler
            client.setCallback(this);

            // Connect to the MQTT server
            System.out.println("Connecting to broker: " + broker);
            client.connect(connOpts);
            System.out.println("Connected");
            
            // Subscribe to a topic
            System.out.println("Subscribe to topic: "+ topic);
            client.subscribe(topic, qos);
        } catch (MqttException me) {
            me.printStackTrace();
        }
    }

    @Override
    public void connectionLost(Throwable thrwbl) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void messageArrived(String topic, MqttMessage message) throws Exception {
        System.out.println(topic+":"+message);
        
        // Time stamp message
        //String time = new Timestamp(System.currentMillis()).toString();
        String time = new Timestamp(System.currentTimeMillis()).toString();
        
        // Set topic
        MqttTopic pubTopic = client.getTopic("ack/123");
        
        // Create and configure a message
        String payload = "Received: "+time;
        MqttMessage msg = new MqttMessage(payload.getBytes());
        msg.setQos(qos);
        
        // Publish back to core
        MqttDeliveryToken token = null;
        System.out.println("Publishing to ACK topic");
        try{
            token = pubTopic.publish(msg);
            
            // Wait for completion
            token.isComplete();
        }catch(Exception e){
            e.printStackTrace();
        }
        
    }

    @Override
    public void deliveryComplete(IMqttDeliveryToken imdt) {
        System.out.println("Delivered " +imdt.hashCode());
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
